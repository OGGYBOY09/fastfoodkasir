package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class KasirPOSForm extends JFrame {

    private int userId;
    private String fullName;
    private static final BigDecimal TAX_RATE = new BigDecimal("0.10"); // 10% Pajak (10%)

    // --- Komponen Data & Logic ---
    private Map<Integer, BigDecimal> productPriceMap; 
    private DefaultTableModel menuTableModel;
    private DefaultTableModel cartTableModel;
    private DefaultTableModel tableStatusTableModel;

    // --- Komponen UI ---
    private JTable cartTable;
    private JTable menuTable;
    private JTable tableStatusTable;
    private JLabel lblTotalTagihan, lblSubtotal, lblTax, lblKembalian;
    private JTextField txtPaymentAmount;
    private JComboBox<String> cmbMember;
    private JButton btnPayment, btnCancel;

    public KasirPOSForm(int userId, String fullName) {
        this.userId = userId;
        this.fullName = fullName;
        this.productPriceMap = new HashMap<>();

        setTitle("KASIR - Point of Sale (POS) - Login: " + fullName);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setupMenuBar();
        
        // --- Layout Utama 3 Kolom ---
        
        JPanel tableAndOrderPanel = createTableAndOrderPanel();
        JPanel menuSelectionPanel = createMenuSelectionPanel();
        JPanel cartAndPaymentPanel = createCartAndPaymentPanel();
        
        JSplitPane centerRightSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, menuSelectionPanel, cartAndPaymentPanel);
        centerRightSplit.setResizeWeight(0.6); 
        
        JSplitPane finalSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableAndOrderPanel, centerRightSplit);
        finalSplit.setDividerLocation(300); 
        
        add(finalSplit, BorderLayout.CENTER);
        
        setupShortcuts();
        loadInitialData();
        calculateTotal(); 
        setVisible(true);
    }

    // --- SETUP UI COMPONENTS ---

    private JPanel createTableAndOrderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("MEJA & STATUS PESANAN"));
        
        String[] columns = {"ID", "No. Meja", "Status"}; 
        tableStatusTableModel = new DefaultTableModel(columns, 0) {
             @Override
             public boolean isCellEditable(int row, int column) { return false; }
        };
        tableStatusTable = new JTable(tableStatusTableModel);
        
        panel.add(new JScrollPane(tableStatusTable), BorderLayout.CENTER);
        
        JButton btnRefreshTables = new JButton("Refresh Status Meja");
        btnRefreshTables.addActionListener(e -> loadTables());
        panel.add(btnRefreshTables, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createMenuSelectionPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("PILIH MENU (F1: Search Product)"));

        String[] columns = {"ID", "Nama Menu", "Kategori", "Harga Jual (Rp)", "Stok"};
        menuTableModel = new DefaultTableModel(columns, 0) {
             @Override
             public boolean isCellEditable(int row, int column) { return false; }
        };
        menuTable = new JTable(menuTableModel);
        
        menuTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    addMenuToOrder(menuTable.getSelectedRow(), 1); 
                }
            }
        });
        
        panel.add(new JScrollPane(menuTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createCartAndPaymentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("KERANJANG BELANJA & PEMBAYARAN"));

        // Keranjang (JTable)
        String[] cartColumns = {"ID", "Menu", "Harga Satuan", "Qty", "Subtotal Item", "Hapus"};
        cartTableModel = new DefaultTableModel(cartColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3 || column == 5; 
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2 || columnIndex == 4) return BigDecimal.class;
                return super.getColumnClass(columnIndex);
            }
        };
        cartTable = new JTable(cartTableModel);
        
        // Tombol Hapus di dalam tabel tetap diberi warna agar mudah dibedakan
        cartTable.getColumn("Hapus").setCellRenderer(new ButtonRenderer());
        cartTable.getColumn("Hapus").setCellEditor(new ButtonEditor(new JTextField(), this::removeOrderItem));
        
        cartTable.getModel().addTableModelListener(e -> {
            if (e.getColumn() == 3) { // Kolom Qty
                updateOrderItem(e.getFirstRow());
            }
        });
        
        panel.add(new JScrollPane(cartTable), BorderLayout.CENTER);
        
        // Panel Total & Pembayaran (SOUTH)
        JPanel paymentControls = new JPanel(new GridBagLayout());
        paymentControls.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 5, 4, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Row 1: Member
        gbc.gridx = 0; gbc.gridy = 0; paymentControls.add(new JLabel("Member:"), gbc);
        gbc.gridx = 1; cmbMember = new JComboBox<>(); paymentControls.add(cmbMember, gbc);
        cmbMember.addActionListener(e -> calculateTotal());

        // Row 2: Subtotal
        gbc.gridx = 0; gbc.gridy = 1; paymentControls.add(new JLabel("Subtotal Pesanan:"), gbc);
        gbc.gridx = 1; lblSubtotal = new JLabel("Rp 0", SwingConstants.RIGHT); paymentControls.add(lblSubtotal, gbc);
        
        // Row 3: Pajak
        gbc.gridx = 0; gbc.gridy = 2; paymentControls.add(new JLabel("Pajak (10%):"), gbc);
        gbc.gridx = 1; lblTax = new JLabel("Rp 0", SwingConstants.RIGHT); paymentControls.add(lblTax, gbc);

        // Row 4: Total Tagihan
        JLabel lblTotalTagihanText = new JLabel("TOTAL TAGIHAN:");
        lblTotalTagihanText.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0; gbc.gridy = 3; paymentControls.add(lblTotalTagihanText, gbc);
        
        gbc.gridx = 1; lblTotalTagihan = new JLabel("Rp 0", SwingConstants.RIGHT); lblTotalTagihan.setFont(new Font("Arial", Font.BOLD, 14)); paymentControls.add(lblTotalTagihan, gbc);
        
        // Row 5: Jumlah Bayar
        gbc.gridx = 0; gbc.gridy = 4; paymentControls.add(new JLabel("Jumlah Bayar (F12):"), gbc);
        gbc.gridx = 1; txtPaymentAmount = new JTextField(15); paymentControls.add(txtPaymentAmount, gbc);
        txtPaymentAmount.addCaretListener(e -> calculateTotal()); 
        
        // Row 6: Kembalian
        JLabel lblKembalianText = new JLabel("Kembalian:");
        lblKembalianText.setFont(new Font("Arial", Font.ITALIC, 12));
        gbc.gridx = 0; gbc.gridy = 5; paymentControls.add(lblKembalianText, gbc);

        gbc.gridx = 1; lblKembalian = new JLabel("Rp 0", SwingConstants.RIGHT); 
        lblKembalian.setFont(new Font("Arial", Font.ITALIC, 12)); 
        lblKembalian.setOpaque(false); 
        paymentControls.add(lblKembalian, gbc);

        // Row 7: Tombol Aksi (Menggunakan warna default)
        
        // Batalkan Transaksi
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 1; 
        btnCancel = new JButton("Batalkan Transaksi");
        btnCancel.addActionListener(e -> resetOrder());
        paymentControls.add(btnCancel, gbc);

        // PROSES PEMBAYARAN
        gbc.gridx = 1; gbc.gridy = 6; gbc.gridwidth = 1; 
        btnPayment = new JButton("PROSES PEMBAYARAN (F12)");
        btnPayment.addActionListener(e -> processPayment());
        paymentControls.add(btnPayment, gbc);
        
        panel.add(paymentControls, BorderLayout.SOUTH);
        return panel;
    }
    
    // --- DATA LOADING ---
    private void loadInitialData() {
        loadTables();
        loadProducts();
        loadMembers();
    }
    
    private void loadTables() {
        tableStatusTableModel.setRowCount(0);
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            stmt = conn.createStatement();
            // Menggunakan kolom 'status' (sesuai skema tabel tables Anda)
            rs = stmt.executeQuery("SELECT table_id, table_number, status FROM tables ORDER BY table_number");

            while (rs.next()) {
                tableStatusTableModel.addRow(new Object[]{
                    rs.getInt("table_id"), 
                    rs.getString("table_number"), 
                    rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat daftar meja: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    private void loadProducts() {
        menuTableModel.setRowCount(0);
        productPriceMap.clear();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            stmt = conn.createStatement();
            // Menggunakan kolom 'price' (sesuai skema produk yang seharusnya)
            rs = stmt.executeQuery("SELECT product_id, name, category, price, stock FROM products WHERE is_available = TRUE ORDER BY name");

            while (rs.next()) {
                int id = rs.getInt("product_id");
                String name = rs.getString("name");
                BigDecimal price = rs.getBigDecimal("price"); 
                int stock = rs.getInt("stock");
                
                menuTableModel.addRow(new Object[]{
                    id, name, rs.getString("category"), price, stock
                });
                productPriceMap.put(id, price);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat daftar menu: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
    
    private void loadMembers() {
        cmbMember.removeAllItems();
        cmbMember.addItem("0 - Non-Member");
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT member_id, full_name FROM members ORDER BY full_name");

            while (rs.next()) {
                int id = rs.getInt("member_id");
                String name = rs.getString("full_name");
                cmbMember.addItem(id + " - " + name);
            }
        } catch (SQLException ex) {
            // Optional: Handle error loading members
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    // --- CART LOGIC ---
    // (Kode addMenuToOrder, updateOrderItem, removeOrderItem tidak berubah)
    
    private void addMenuToOrder(int menuRow, int quantityToAdd) {
        if (menuRow < 0) return;
        
        int productId = (int) menuTableModel.getValueAt(menuRow, 0);
        String name = (String) menuTableModel.getValueAt(menuRow, 1);
        BigDecimal price = (BigDecimal) menuTableModel.getValueAt(menuRow, 3);
        int currentStock = (int) menuTableModel.getValueAt(menuRow, 4);

        if (currentStock <= 0) {
            JOptionPane.showMessageDialog(this, "Stok " + name + " sedang kosong.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int quantity = quantityToAdd;

        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            if ((int) cartTableModel.getValueAt(i, 0) == productId) {
                int currentQty = (int) cartTableModel.getValueAt(i, 3);
                int newQty = currentQty + quantityToAdd;
                
                if (newQty > currentStock) {
                    JOptionPane.showMessageDialog(this, "Jumlah pesanan melebihi stok yang tersedia (" + currentStock + ").", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                cartTableModel.setValueAt(newQty, i, 3);
                updateOrderItem(i);
                return;
            }
        }

        if (quantity > currentStock) {
             JOptionPane.showMessageDialog(this, "Jumlah pesanan melebihi stok yang tersedia (" + currentStock + ").", "Peringatan", JOptionPane.WARNING_MESSAGE);
             return;
        }
        
        BigDecimal subtotal = price.multiply(new BigDecimal(quantity));
        cartTableModel.addRow(new Object[]{
            productId, name, price, quantity, subtotal, "Hapus"
        });

        calculateTotal();
    }
    
    private void updateOrderItem(int row) {
        if (row < 0 || row >= cartTableModel.getRowCount()) return;

        try {
            int productId = (int) cartTableModel.getValueAt(row, 0);
            int newQuantity = Integer.parseInt(cartTableModel.getValueAt(row, 3).toString());
            
            int currentStock = 0;
            for(int i = 0; i < menuTableModel.getRowCount(); i++) {
                if((int) menuTableModel.getValueAt(i, 0) == productId) {
                    currentStock = (int) menuTableModel.getValueAt(i, 4);
                    break;
                }
            }
            
            if (newQuantity <= 0) {
                 cartTableModel.removeRow(row);
                 calculateTotal();
                 return;
            }
            
            if (newQuantity > currentStock) {
                JOptionPane.showMessageDialog(this, "Jumlah pesanan melebihi stok yang tersedia (" + currentStock + ").", "Peringatan", JOptionPane.WARNING_MESSAGE);
                cartTableModel.setValueAt(1, row, 3); 
                newQuantity = 1;
            }

            BigDecimal price = productPriceMap.get(productId);
            BigDecimal newSubtotal = price.multiply(new BigDecimal(newQuantity));
            
            cartTableModel.setValueAt(newSubtotal, row, 4);
            calculateTotal();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Kuantitas harus berupa angka valid.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void removeOrderItem(int row) {
        cartTableModel.removeRow(row);
        calculateTotal();
    }
    
    // --- CALCULATION LOGIC ---
    
    private void calculateTotal() {
        BigDecimal subtotal = BigDecimal.ZERO;
        
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            BigDecimal itemSubtotal = (BigDecimal) cartTableModel.getValueAt(i, 4);
            subtotal = subtotal.add(itemSubtotal);
        }
        
        BigDecimal subtotalBeforeDiscount = subtotal; 
        
        // --- Diskon Member (5% diskon jika member) ---
        BigDecimal memberDiscount = BigDecimal.ZERO;
        String selectedMember = (String) cmbMember.getSelectedItem();
        if (selectedMember != null && !selectedMember.startsWith("0")) {
             BigDecimal discountRate = new BigDecimal("0.05");
             memberDiscount = subtotal.multiply(discountRate);
             subtotal = subtotal.subtract(memberDiscount);
        }
        
        BigDecimal tax = subtotal.multiply(TAX_RATE);
        BigDecimal total = subtotal.add(tax);

        lblSubtotal.setText("Rp " + formatCurrency(subtotalBeforeDiscount)); 
        lblTax.setText("Rp " + formatCurrency(tax));
        lblTotalTagihan.setText("Rp " + formatCurrency(total));
        lblKembalian.setText("Rp " + formatCurrency(calculateChange(total)));
    }

    private BigDecimal calculateChange(BigDecimal total) {
        try {
            BigDecimal paymentAmount = new BigDecimal(txtPaymentAmount.getText().trim().replaceAll(",", "")); 
            return paymentAmount.compareTo(total) > 0 ? paymentAmount.subtract(total) : BigDecimal.ZERO;
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }
    
    // --- TRANSACTION LOGIC ---
    
    // --- Metode Baru: Dialog untuk Memilih Metode Pembayaran ---
    private String showPaymentMethodDialog() {
        String[] options = {"CASH", "DEBIT", "CREDIT"};
        JComboBox<String> cmbPaymentMethod = new JComboBox<>(options);
        
        int result = JOptionPane.showOptionDialog(this,
            cmbPaymentMethod,
            "Pilih Metode Pembayaran",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[]{"Lanjutkan Pembayaran", "Batal"},
            "Lanjutkan Pembayaran");

        if (result == 0) { // Lanjutkan Pembayaran
            return (String) cmbPaymentMethod.getSelectedItem();
        } else {
            return null; // Batal
        }
    }

    private void processPayment() {
        if (cartTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Keranjang pesanan masih kosong.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        BigDecimal totalAmount = extractBigDecimal(lblTotalTagihan.getText());
        int tableRow = tableStatusTable.getSelectedRow();
        int tableId = -1;
        
        // 1. Validasi Meja
        if (tableRow != -1) {
            tableId = (int) tableStatusTableModel.getValueAt(tableRow, 0);
            String tableStatus = (String) tableStatusTableModel.getValueAt(tableRow, 2);
            if (!tableStatus.equals("Available") && !tableStatus.equals("Reserved")) {
                 JOptionPane.showMessageDialog(this, "Meja yang dipilih saat ini berstatus: " + tableStatus + ". Harap pilih meja 'Available' atau 'Reserved'.", "Peringatan Meja", JOptionPane.WARNING_MESSAGE);
                 return;
            }
        }
        
        // 2. Validasi Jumlah Bayar
        BigDecimal paymentAmount;
        try {
            paymentAmount = new BigDecimal(txtPaymentAmount.getText().trim().replaceAll(",", ""));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah Bayar harus berupa angka valid.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (paymentAmount.compareTo(totalAmount) < 0) {
            JOptionPane.showMessageDialog(this, "Jumlah bayar kurang dari total yang harus dibayar!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        BigDecimal change = paymentAmount.subtract(totalAmount);
        
        // 3. Ambil Metode Pembayaran
        String paymentMethod = showPaymentMethodDialog();
        if (paymentMethod == null) {
            return; // Dibatalkan oleh user
        }
        
        // 4. Konfirmasi
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Metode Pembayaran: " + paymentMethod + "\n" +
            "Total: Rp " + formatCurrency(totalAmount) + "\n" + 
            "Bayar: Rp " + formatCurrency(paymentAmount) + "\n" +
            "Kembalian: Rp " + formatCurrency(change) + "\n\n" +
            "Selesaikan transaksi?", "Konfirmasi Pembayaran", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            String memberInfo = (String) cmbMember.getSelectedItem();
            int memberId = Integer.parseInt(memberInfo.split(" - ")[0]);
            
            // Panggil saveTransaction dengan paymentMethod baru
            if (saveTransaction(tableId, memberId, totalAmount, paymentMethod)) { 
                JOptionPane.showMessageDialog(this, "Transaksi berhasil!\nKembalian: Rp " + formatCurrency(change), "Sukses", JOptionPane.INFORMATION_MESSAGE);
                resetOrder();
            }
        }
    }
    
    // --- Metode saveTransaction Disesuaikan dengan Tabel Transaksi Anda ---
    private boolean saveTransaction(int tableId, int memberId, BigDecimal totalAmount, String paymentMethod) {
        Connection conn = null;
        PreparedStatement pstmtTrans = null;
        PreparedStatement pstmtDetails = null;
        PreparedStatement pstmtStock = null;
        PreparedStatement pstmtTable = null;
        ResultSet rs = null;
        int transactionId = -1;

        try {
            conn = DatabaseConnector.getConnection();
            conn.setAutoCommit(false); 

            // 1. INSERT ke transactions
            // Disesuaikan untuk menyertakan payment_method dan transaction_status='Paid'
            String sqlTrans = "INSERT INTO transactions (transaction_date, user_id, table_id, member_id, total_amount, payment_method, transaction_status) VALUES (NOW(), ?, ?, ?, ?, ?, 'Paid') RETURNING transaction_id";
            pstmtTrans = conn.prepareStatement(sqlTrans);
            
            pstmtTrans.setInt(1, userId);
            pstmtTrans.setObject(2, tableId == -1 ? null : tableId); 
            pstmtTrans.setObject(3, memberId == 0 ? null : memberId); 
            pstmtTrans.setBigDecimal(4, totalAmount);
            pstmtTrans.setString(5, paymentMethod); // <-- Solusi untuk error NOT NULL
            
            rs = pstmtTrans.executeQuery();
            if (rs.next()) {
                transactionId = rs.getInt("transaction_id");
            } else {
                throw new SQLException("Gagal mendapatkan transaction_id.");
            }

            // 2. INSERT ke transaction_details dan UPDATE stock
            String sqlDetails = "INSERT INTO transaction_details (transaction_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
            String sqlStock = "UPDATE products SET stock = stock - ? WHERE product_id = ?";
            
            pstmtDetails = conn.prepareStatement(sqlDetails);
            pstmtStock = conn.prepareStatement(sqlStock);

            for (int i = 0; i < cartTableModel.getRowCount(); i++) {
                int productId = (int) cartTableModel.getValueAt(i, 0);
                int quantity = (int) cartTableModel.getValueAt(i, 3);
                BigDecimal unitPrice = (BigDecimal) cartTableModel.getValueAt(i, 2);
                BigDecimal subtotalItem = (BigDecimal) cartTableModel.getValueAt(i, 4);

                // Detail
                pstmtDetails.setInt(1, transactionId);
                pstmtDetails.setInt(2, productId);
                pstmtDetails.setInt(3, quantity);
                pstmtDetails.setBigDecimal(4, unitPrice);
                pstmtDetails.setBigDecimal(5, subtotalItem);
                pstmtDetails.addBatch();
                
                // Stock
                pstmtStock.setInt(1, quantity);
                pstmtStock.setInt(2, productId);
                pstmtStock.addBatch();
            }
            
            pstmtDetails.executeBatch();
            pstmtStock.executeBatch();

            // 3. UPDATE Status Meja menjadi 'Occupied'
            if (tableId != -1) {
                 String sqlTable = "UPDATE tables SET status = 'Occupied' WHERE table_id = ?";
                 pstmtTable = conn.prepareStatement(sqlTable);
                 pstmtTable.setInt(1, tableId);
                 pstmtTable.executeUpdate();
            }

            conn.commit(); 
            return true;
            
        } catch (SQLException ex) {
            try {
                if (conn != null) conn.rollback(); 
            } catch (SQLException rbex) {
                // Ignore rollback error
            }
            JOptionPane.showMessageDialog(this, "Gagal menyimpan transaksi: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
    
    private void resetOrder() {
        cartTableModel.setRowCount(0);
        txtPaymentAmount.setText("");
        cmbMember.setSelectedIndex(0);
        calculateTotal();
        loadInitialData(); 
    }
    
    // --- HELPER METHODS ---
    
    private String formatCurrency(BigDecimal amount) {
        return String.format("%,.0f", amount);
    }
    
    private BigDecimal extractBigDecimal(String labelText) {
        String s = labelText.replaceAll("[^\\d\\.]", "");
        return s.isEmpty() ? BigDecimal.ZERO : new BigDecimal(s);
    }
    
    // --- SHORTCUTS ---
    private void setupShortcuts() {
        JRootPane rootPane = this.getRootPane();
        
        Action searchAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(rootPane, "Shortcut F1 ditekan: Cari Menu atau double click untuk menambah item.");
                menuTable.requestFocusInWindow();
            }
        };
        rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0), "searchProduct");
        rootPane.getActionMap().put("searchProduct", searchAction);

        Action paymentAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtPaymentAmount.requestFocusInWindow();
                processPayment();
            }
        };
        rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_F12, 0), "processPayment");
        rootPane.getActionMap().put("processPayment", paymentAction);
    }

    private void setupMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu("File");
        
        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.CTRL_MASK)); 
        
        logoutItem.addActionListener(e -> {
            int dialogResult = JOptionPane.showConfirmDialog(this, "Anda yakin ingin Logout?", "Konfirmasi Logout", JOptionPane.YES_NO_OPTION);
            if (dialogResult == JOptionPane.YES_OPTION) {
                // Asumsi Anda memiliki LoginForm
                // new LoginForm().setVisible(true); 
                this.dispose(); 
            }
        });
        
        menuFile.add(logoutItem);
        menuBar.add(menuFile);
        
        JMenu menuHelp = new JMenu("Help");
        JMenuItem shortcutInfo = new JMenuItem("Shortcut Keys");
        menuHelp.add(shortcutInfo);
        menuBar.add(menuHelp);
        
        setJMenuBar(menuBar);
    }
    
    // --- Custom Renderer/Editor untuk Tombol Hapus ---
    
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setText("Hapus");
            setBackground(Color.RED);
            setForeground(Color.WHITE);
        }
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private int row;

        public ButtonEditor(JTextField textField, java.util.function.Consumer<Integer> deleteAction) {
            super(textField);
            setClickCountToStart(1);
            
            button = new JButton("Hapus");
            button.setOpaque(true);
            button.setBackground(Color.RED);
            button.setForeground(Color.WHITE);
            
            button.addActionListener(e -> {
                fireEditingStopped();
                deleteAction.accept(row);
            });
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            this.row = row;
            return button;
        }
    }
}