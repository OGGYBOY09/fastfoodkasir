package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ManajemenMejaPanel extends JPanel {

    private JTextField txtTableNumber, txtCapacity;
    // JComboBox ini sekarang mengelola Status (String), bukan hanya Ketersediaan (Boolean)
    private JComboBox<String> cmbStatus; 
    private JButton btnAdd, btnUpdate, btnDelete;
    private JTable table;
    private DefaultTableModel tableModel;
    private int selectedTableId = -1;
    
    // Daftar Status yang sesuai dengan skema DB Anda
    private final String[] TABLE_STATUSES = {"Available", "Occupied", "Cleaning", "Reserved"};

    public ManajemenMejaPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Setup Form
        JPanel inputPanel = createInputPanel();
        add(inputPanel, BorderLayout.NORTH);

        // Setup Table
        JScrollPane tableScrollPane = createTablePanel();
        add(tableScrollPane, BorderLayout.CENTER);

        loadTableData();
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Manajemen Data Meja"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label dan Field Meja
        gbc.gridx = 0; gbc.gridy = 0; panel.add(new JLabel("Nomor Meja:"), gbc);
        gbc.gridx = 1; txtTableNumber = new JTextField(15); panel.add(txtTableNumber, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panel.add(new JLabel("Kapasitas:"), gbc);
        gbc.gridx = 1; txtCapacity = new JTextField(15); panel.add(txtCapacity, gbc);

        // *** KOLOM STATUS ***
        gbc.gridx = 2; gbc.gridy = 0; panel.add(new JLabel("Status:"), gbc);
        cmbStatus = new JComboBox<>(TABLE_STATUSES); 
        gbc.gridx = 3; panel.add(cmbStatus, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btnAdd = new JButton("Tambah");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Hapus");
        
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        
        gbc.gridx = 3; gbc.gridy = 1; panel.add(buttonPanel, gbc);
        
        setupListeners();
        
        return panel;
    }

    private JScrollPane createTablePanel() {
        // *** Ganti nama kolom dari "Tersedia" menjadi "Status" ***
        String[] columnNames = {"ID", "Nomor Meja", "Kapasitas", "Status"}; 
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                // Semua kolom sekarang dianggap Object/String
                return super.getColumnClass(columnIndex); 
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                displaySelectedTable();
            }
        });
        return new JScrollPane(table);
    }
    
    private void setupListeners() {
        btnAdd.addActionListener(e -> addTable());
        btnUpdate.addActionListener(e -> updateTable());
        btnDelete.addActionListener(e -> deleteTable());
    }
    
    // --- CRUD OPERATIONS ---
    
    private void loadTableData() {
        tableModel.setRowCount(0);
        selectedTableId = -1;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            stmt = conn.createStatement();
            // *** Ganti is_available menjadi status ***
            rs = stmt.executeQuery("SELECT table_id, table_number, capacity, status FROM tables ORDER BY table_number");

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("table_id"),
                    rs.getString("table_number"),
                    rs.getInt("capacity"),
                    // Mengambil status sebagai String
                    rs.getString("status") 
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data meja: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
    
    private void displaySelectedTable() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        selectedTableId = (int) tableModel.getValueAt(row, 0);
        txtTableNumber.setText(tableModel.getValueAt(row, 1).toString());
        txtCapacity.setText(tableModel.getValueAt(row, 2).toString());
        
        // Mengatur JComboBox berdasarkan status String yang dimuat dari tabel
        String currentStatus = tableModel.getValueAt(row, 3).toString();
        cmbStatus.setSelectedItem(currentStatus);
    }
    
    private void addTable() {
        String number = txtTableNumber.getText().trim();
        String capacityStr = txtCapacity.getText().trim();
        // *** Mengambil status sebagai String ***
        String status = cmbStatus.getSelectedItem().toString(); 
        
        if (number.isEmpty() || capacityStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nomor Meja dan Kapasitas wajib diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnector.getConnection();
             // *** Ganti is_available menjadi status ***
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO tables (table_number, capacity, status) VALUES (?, ?, ?)")) {
            
            pstmt.setString(1, number);
            pstmt.setInt(2, Integer.parseInt(capacityStr));
            pstmt.setString(3, status); // Menggunakan setString
            
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Meja berhasil ditambahkan.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadTableData();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Kapasitas harus berupa angka.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menambah meja: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTable() {
        if (selectedTableId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih meja yang akan diupdate.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String number = txtTableNumber.getText().trim();
        String capacityStr = txtCapacity.getText().trim();
        // *** Mengambil status sebagai String ***
        String status = cmbStatus.getSelectedItem().toString(); 

        if (number.isEmpty() || capacityStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nomor Meja dan Kapasitas wajib diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try (Connection conn = DatabaseConnector.getConnection();
             // *** Ganti is_available menjadi status ***
             PreparedStatement pstmt = conn.prepareStatement("UPDATE tables SET table_number = ?, capacity = ?, status = ? WHERE table_id = ?")) {
            
            pstmt.setString(1, number);
            pstmt.setInt(2, Integer.parseInt(capacityStr));
            pstmt.setString(3, status); // Menggunakan setString
            pstmt.setInt(4, selectedTableId);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Meja berhasil diupdate.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadTableData();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Kapasitas harus berupa angka.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal mengupdate meja: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteTable() {
        if (selectedTableId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih meja yang akan dihapus.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus meja " + txtTableNumber.getText() + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnector.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM tables WHERE table_id = ?")) {
                
                pstmt.setInt(1, selectedTableId);
                pstmt.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Meja berhasil dihapus.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
                loadTableData();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus meja: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void clearFields() {
        txtTableNumber.setText("");
        txtCapacity.setText("");
        cmbStatus.setSelectedIndex(0);
        selectedTableId = -1;
        table.clearSelection();
    }
}