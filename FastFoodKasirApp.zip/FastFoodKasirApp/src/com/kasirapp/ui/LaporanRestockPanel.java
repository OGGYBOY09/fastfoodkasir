package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class LaporanRestockPanel extends JPanel {

    private JTextField dateFromField, dateUntilField;
    private JComboBox<String> typeFilter;
    private JButton filterButton;
    private JTable reportTable;
    private DefaultTableModel tableModel;

    public LaporanRestockPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- 1. Panel Filter (NORTH) ---
        JPanel filterPanel = createFilterPanel();
        add(filterPanel, BorderLayout.NORTH);
        
        // --- 2. Panel Tabel Laporan (CENTER) ---
        JPanel tableContainer = createTablePanel();
        add(tableContainer, BorderLayout.CENTER);
        
        // Muat data awal (misalnya, 7 hari terakhir)
        loadReportData(null, getOneWeekAgoDate(), getCurrentDate()); // NULL untuk tipe (semua)
    }

    private JPanel createFilterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Filter Laporan Pergerakan Stok"));

        dateFromField = new JTextField(10);
        dateUntilField = new JTextField(10);
        typeFilter = new JComboBox<>(new String[]{"Semua", "IN (Masuk)", "OUT (Keluar)"});
        filterButton = new JButton("Tampilkan Laporan");
        
        // Set tanggal default
        dateFromField.setText(getOneWeekAgoDate());
        dateUntilField.setText(getCurrentDate());

        panel.add(new JLabel("Dari Tanggal (YYYY-MM-DD):"));
        panel.add(dateFromField);
        panel.add(new JLabel("Sampai Tanggal (YYYY-MM-DD):"));
        panel.add(dateUntilField);
        panel.add(new JLabel("Tipe Gerakan:"));
        panel.add(typeFilter);
        panel.add(filterButton);

        filterButton.addActionListener(e -> applyFilter());

        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Detail Pergerakan Stok"));

        String[] columnNames = {"ID Gerakan", "Tanggal", "Nama Produk", "Tipe", "Perubahan Qty", "Alasan", "Oleh Pengguna"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        reportTable = new JTable(tableModel);
        
        panel.add(new JScrollPane(reportTable), BorderLayout.CENTER);
        return panel;
    }

    // Metode Helper untuk Tanggal
    private String getCurrentDate() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
    }
    
    private String getOneWeekAgoDate() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.add(java.util.Calendar.DATE, -7);
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
    }
    
    // Logika Filter
    private void applyFilter() {
        String dateFrom = dateFromField.getText();
        String dateUntil = dateUntilField.getText();
        String selectedType = typeFilter.getSelectedItem().toString();
        
        String typeCode = null;
        if (selectedType.contains("IN")) {
            typeCode = "IN";
        } else if (selectedType.contains("OUT")) {
            typeCode = "OUT";
        }
        
        loadReportData(typeCode, dateFrom, dateUntil);
    }
    
    // Logika Database (READ)
    // *** loadReportData sudah memiliki parameter yang benar: typeCode, dateFrom, dateUntil ***
    private void loadReportData(String typeCode, String dateFrom, String dateUntil) {
        tableModel.setRowCount(0);
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            
            // Query JOIN dan KOREKSI POSTGRESQL (CAST TIMESTAMP)
            String sql = "SELECT sm.movement_id, sm.movement_date, p.name AS product_name, sm.type, sm.quantity_change, sm.reason, u.full_name " +
                         "FROM stock_movements sm " +
                         "JOIN products p ON sm.product_id = p.product_id " +
                         "JOIN users u ON sm.user_id = u.user_id " +
                         // *** KOREKSI 1: Gunakan CAST(? AS TIMESTAMP) ***
                         "WHERE sm.movement_date BETWEEN CAST(? AS TIMESTAMP) AND CAST(? AS TIMESTAMP)";
            
            if (typeCode != null) {
                // *** KOREKSI 2: Pastikan ada spasi jika klausa ini ditambahkan ***
                sql += " AND sm.type = ?";
            }
            
            // *** KOREKSI 3: Pastikan ada spasi di awal ORDER BY untuk mencegah syntax error ***
            sql += " ORDER BY sm.movement_date DESC";
            
            pstmt = conn.prepareStatement(sql);
            
            // Mengatur parameter tanggal
            pstmt.setString(1, dateFrom + " 00:00:00"); 
            pstmt.setString(2, dateUntil + " 23:59:59"); 
            
            // Mengatur parameter tipe jika ada
            if (typeCode != null) {
                pstmt.setString(3, typeCode);
            }

            rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("movement_id"),
                    rs.getTimestamp("movement_date"),
                    rs.getString("product_name"),
                    rs.getString("type"),
                    rs.getInt("quantity_change"),
                    rs.getString("reason"),
                    rs.getString("full_name")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat laporan stok: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
}