package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class LoginForm extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginForm() {
        setTitle("FastFood Kasir - Sistem Login Restoran");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // --- Setup Background Utama ---
        setLayout(new BorderLayout());
        JPanel mainBackground = new JPanel(new GridBagLayout());
        mainBackground.setBackground(new Color(45, 52, 54)); 
        add(mainBackground, BorderLayout.CENTER);
        
        // Warna Teks Gelap
        Color darkTextColor = new Color(45, 52, 54);

        // --- Panel Form Login (Focus Panel) ---
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.WHITE); 
        loginPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        loginPanel.setPreferredSize(new Dimension(350, 300)); 

        // Style Font
        Font labelFont = new Font("Arial", Font.PLAIN, 12);
        Font titleFont = new Font("Arial", Font.BOLD, 20);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);

        // --- 1. Title ---
        JLabel titleLabel = new JLabel("Login Kasir");
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(darkTextColor);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; 
        loginPanel.add(titleLabel, gbc);

        // --- 2. Username ---
        JLabel userLabel = new JLabel("USERNAME:");
        userLabel.setFont(labelFont);
        userLabel.setForeground(darkTextColor);
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        loginPanel.add(userLabel, gbc);

        usernameField = new JTextField(20);
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        loginPanel.add(usernameField, gbc);

        // --- 3. Password ---
        JLabel passLabel = new JLabel("PASSWORD:");
        passLabel.setFont(labelFont);
        passLabel.setForeground(darkTextColor);
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        loginPanel.add(passLabel, gbc);

        passwordField = new JPasswordField(20);
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        loginPanel.add(passwordField, gbc);

        // --- 4. Tombol Login ---
        loginButton = new JButton("MASUK (Enter)");
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        // WARNA HIJAU MINT GELAP
        loginButton.setBackground(new Color(39, 174, 96)); 
        loginButton.setForeground(Color.WHITE); 
        
        // KUNCI PERBAIKAN VISIBILITAS:
        loginButton.setOpaque(true); 
        loginButton.setBorderPainted(false); // Hilangkan border default
        loginButton.setFocusPainted(false);
        
        loginButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 
        
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 0, 5, 0); 
        loginPanel.add(loginButton, gbc);
        
        // --- 5. Petunjuk Shortcut ---
        JLabel hintLabel = new JLabel("Gunakan tombol Enter untuk masuk");
        hintLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        hintLabel.setForeground(Color.GRAY);
        gbc.gridy = 6;
        gbc.insets = new Insets(0, 0, 0, 0); 
        loginPanel.add(hintLabel, gbc);
        
        mainBackground.add(loginPanel); 

        // --- Aksi Tombol dan Shortcut ---
        ActionListener loginAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptLogin();
            }
        };
        
        loginButton.addActionListener(loginAction);
        usernameField.addActionListener(loginAction);
        passwordField.addActionListener(loginAction);
    }
    
    // ********************************************
    // Metode attemptLogin() - Logika Login ke DB
    // ********************************************
    private void attemptLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword()); 

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username dan Password harus diisi.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            String sql = "SELECT user_id, role, full_name FROM users WHERE username = ? AND password = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                int userId = rs.getInt("user_id");
                String fullName = rs.getString("full_name");
                
                JOptionPane.showMessageDialog(this, "Selamat datang, " + fullName + " (" + role + ")!", "Login Sukses", JOptionPane.INFORMATION_MESSAGE);
                
                if ("Admin".equalsIgnoreCase(role)) {
                    new AdminDashboard(userId, fullName).setVisible(true);
                } else if ("Kasir".equalsIgnoreCase(role)) {
                    new KasirPOSForm(userId, fullName).setVisible(true);
                }
                
                this.dispose(); 
                
            } else {
                JOptionPane.showMessageDialog(this, "Username atau Password salah.", "Login Gagal", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Kesalahan database: " + ex.getMessage(), "Error SQL", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }
}