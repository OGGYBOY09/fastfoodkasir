package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.math.BigDecimal;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LaporanPenjualanPanel extends JPanel {

    private JTextField dateFromField, dateUntilField;
    private JButton filterButton;
    private JTable summaryTable, detailTable;
    private DefaultTableModel summaryTableModel, detailTableModel;
    private JLabel totalRevenueLabel;

    public LaporanPenjualanPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- 1. Panel Filter (NORTH) ---
        JPanel filterPanel = createFilterPanel();
        add(filterPanel, BorderLayout.NORTH);
        
        // --- 2. Panel Tabel (CENTER & SOUTH) ---
        JPanel contentPanel = createContentPanel();
        add(contentPanel, BorderLayout.CENTER);
        
        // Muat data awal (TANGGAL DEFAULT)
        loadSummaryReport(getOneWeekAgoDate(), getCurrentDate());
    }
    
    // Metode Helper untuk Tanggal
    private String getCurrentDate() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
    }
    
    private String getOneWeekAgoDate() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.add(java.util.Calendar.DATE, -7);
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
    }

    private JPanel createFilterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Filter Laporan Penjualan"));

        dateFromField = new JTextField(10);
        dateUntilField = new JTextField(10);
        filterButton = new JButton("Tampilkan Laporan");
        
        dateFromField.setText(getOneWeekAgoDate());
        dateUntilField.setText(getCurrentDate());

        panel.add(new JLabel("Dari Tanggal (YYYY-MM-DD):"));
        panel.add(dateFromField);
        panel.add(new JLabel("Sampai Tanggal (YYYY-MM-DD):"));
        panel.add(dateUntilField);
        panel.add(filterButton);

        filterButton.addActionListener(e -> applyFilter());

        return panel;
    }
    
    private JPanel createContentPanel() {
        
        // --- Ringkasan Transaksi ---
        String[] summaryCols = {"ID Transaksi", "Tanggal", "Waktu", "Total Bayar (Rp)", "Dibayar Oleh"};
        summaryTableModel = new DefaultTableModel(summaryCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        summaryTable = new JTable(summaryTableModel);
        
        // Listener untuk memuat detail saat baris dipilih
        summaryTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadDetailReport();
            }
        });
        
        JPanel summaryPanel = new JPanel(new BorderLayout());
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Ringkasan Transaksi"));
        summaryPanel.add(new JScrollPane(summaryTable), BorderLayout.CENTER);

        // --- Detail Item Transaksi ---
        String[] detailCols = {"ID Produk", "Nama Produk", "Harga Satuan (Rp)", "Kuantitas", "Subtotal (Rp)"};
        detailTableModel = new DefaultTableModel(detailCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        detailTable = new JTable(detailTableModel);

        JPanel detailPanel = new JPanel(new BorderLayout());
        detailPanel.setBorder(BorderFactory.createTitledBorder("Detail Item Transaksi yang Dipilih"));
        detailPanel.add(new JScrollPane(detailTable), BorderLayout.CENTER);
        
        // --- Label Total Pendapatan (Footer) ---
        totalRevenueLabel = new JLabel("TOTAL PENDAPATAN: Rp 0", SwingConstants.RIGHT);
        totalRevenueLabel.setFont(new Font("Arial", Font.BOLD, 18));
        totalRevenueLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Gabungkan Ringkasan dan Detail menggunakan SplitPane
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, summaryPanel, detailPanel);
        splitPane.setResizeWeight(0.6); 

        JPanel content = new JPanel(new BorderLayout());
        content.add(splitPane, BorderLayout.CENTER);
        content.add(totalRevenueLabel, BorderLayout.SOUTH);
        
        return content;
    }

    private void applyFilter() {
        String dateFrom = dateFromField.getText();
        String dateUntil = dateUntilField.getText();
        loadSummaryReport(dateFrom, dateUntil);
        detailTableModel.setRowCount(0); // Bersihkan detail saat filter baru
    }
    
    // Logika Database (READ - Ringkasan)
    // *** PARAMETER dateFrom dan dateUntil sudah DITAMBAHKAN KEMBALI ***
    private void loadSummaryReport(String dateFrom, String dateUntil) {
        summaryTableModel.setRowCount(0);
        totalRevenueLabel.setText("TOTAL PENDAPATAN: Rp 0");
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        BigDecimal totalRevenue = BigDecimal.ZERO;

        try {
            conn = DatabaseConnector.getConnection();
            
            // Query JOIN dan KOREKSI POSTGRESQL (CAST TIMESTAMP)
            String sql = "SELECT t.transaction_id, t.transaction_date, t.total_amount, u.full_name " +
                         "FROM transactions t " +
                         "JOIN users u ON t.user_id = u.user_id " +
                         // *** KOREKSI DI SINI: Gunakan CAST(? AS TIMESTAMP) ***
                         "WHERE t.transaction_date BETWEEN CAST(? AS TIMESTAMP) AND CAST(? AS TIMESTAMP) ORDER BY t.transaction_date DESC";
            
            pstmt = conn.prepareStatement(sql);
            
            // Menggunakan parameter dateFrom dan dateUntil yang sekarang sudah tersedia
            pstmt.setString(1, dateFrom + " 00:00:00");
            pstmt.setString(2, dateUntil + " 23:59:59");
            
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("transaction_date");
                totalRevenue = totalRevenue.add(rs.getBigDecimal("total_amount"));
                
                Object[] row = new Object[]{
                    rs.getInt("transaction_id"),
                    new java.text.SimpleDateFormat("yyyy-MM-dd").format(ts),
                    new java.text.SimpleDateFormat("HH:mm:ss").format(ts),
                    rs.getBigDecimal("total_amount"),
                    rs.getString("full_name")
                };
                summaryTableModel.addRow(row);
            }
            
            totalRevenueLabel.setText("TOTAL PENDAPATAN: Rp " + totalRevenue.toPlainString());

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat laporan penjualan: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
    
    // Logika Database (READ - Detail)
    // Di dalam LaporanPenjualanPanel.java, method loadDetailReport()

private void loadDetailReport() {
    int selectedRow = summaryTable.getSelectedRow();
    if (selectedRow == -1) return;
    
    int transactionId = (int) summaryTableModel.getValueAt(selectedRow, 0);
    detailTableModel.setRowCount(0);
    
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        conn = DatabaseConnector.getConnection();
        
        // *** KOREKSI DI SINI: Mengganti td.price_at_sale/td.price dengan td.unit_price ***
        // Menggunakan AS price_at_sale agar tetap kompatibel dengan kode Java di bawahnya
        String sql = "SELECT td.product_id, p.name AS product_name, td.unit_price AS price_at_sale, td.quantity, td.subtotal " +
                     "FROM transaction_details td " +
                     "JOIN products p ON td.product_id = p.product_id " +
                     "WHERE td.transaction_id = ?";
        
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, transactionId);
        
        rs = pstmt.executeQuery();

        while (rs.next()) {
            Object[] row = new Object[]{
                rs.getInt("product_id"),
                rs.getString("product_name"),
                // Mengambil nilai dari kolom yang di-alias AS price_at_sale
                rs.getBigDecimal("price_at_sale"), 
                rs.getInt("quantity"),
                rs.getBigDecimal("subtotal")
            };
            detailTableModel.addRow(row);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Gagal memuat detail transaksi: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        DatabaseConnector.closeConnection(conn);
    }

    }
}