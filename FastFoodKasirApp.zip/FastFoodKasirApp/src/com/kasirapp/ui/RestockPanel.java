package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class RestockPanel extends JPanel {

    private JComboBox<String> productCombo;
    private JTextField quantityField, reasonField;
    private JButton restockButton;
    private JTable stockTable;
    private DefaultTableModel stockTableModel;

    private Vector<ProductItem> productList = new Vector<>();
    private int adminUserId; 

    public RestockPanel(int userId) {
        this.adminUserId = userId;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = createRestockFormPanel();
        JPanel tablePanel = createStockTablePanel();

        add(formPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        
        loadProductList(); 
        loadStockData();
    }

    private static class ProductItem {
        private int id;
        private String name;
        public ProductItem(int id, String name) {
            this.id = id;
            this.name = name;
        }
        @Override
        public String toString() {
            return name;
        }
        public int getId() {
            return id;
        }
    }
    
    private void loadProductList() {
        productList.clear();
        Connection conn = null;
        try {
            conn = DatabaseConnector.getConnection();
            String sql = "SELECT product_id, name FROM products ORDER BY name";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            productCombo.removeAllItems();
            while (rs.next()) {
                ProductItem item = new ProductItem(rs.getInt("product_id"), rs.getString("name"));
                productList.add(item);
                productCombo.addItem(item.toString());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat daftar produk: " + ex.getMessage());
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    private JPanel createRestockFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Input Restock / Penyesuaian Stok Masuk"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        productCombo = new JComboBox<>();
        quantityField = new JTextField(10);
        reasonField = new JTextField(30);
        
        restockButton = new JButton("Proses Restock Stok (IN)");
        restockButton.setBackground(new Color(46, 204, 113));
        restockButton.setForeground(Color.WHITE);
        
        // KUNCI PERBAIKAN VISIBILITAS
        restockButton.setOpaque(true); 
        restockButton.setBorderPainted(false); 
        restockButton.setFocusPainted(false);

        // Layout (Label & Field)
        int row = 0;
        gbc.gridx = 0; gbc.gridy = row; panel.add(new JLabel("Pilih Produk:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; panel.add(productCombo, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0; panel.add(new JLabel("Jumlah Masuk:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; panel.add(quantityField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0; panel.add(new JLabel("Alasan/Sumber:"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; panel.add(reasonField, gbc);
        
        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2; gbc.insets = new Insets(10, 5, 5, 5);
        panel.add(restockButton, gbc);

        restockButton.addActionListener(e -> processRestock());

        return panel;
    }

    private JPanel createStockTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Status Stok Menu Saat Ini (Realtime)"));

        String[] columnNames = {"ID", "Nama Menu", "Kategori", "Harga Jual", "Stok Saat Ini", "Tersedia"};
        stockTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        stockTable = new JTable(stockTableModel);
        
        panel.add(new JScrollPane(stockTable), BorderLayout.CENTER);
        return panel;
    }
    
    private void loadStockData() {
        stockTableModel.setRowCount(0);
        Connection conn = null;
        try {
            conn = DatabaseConnector.getConnection();
            String sql = "SELECT product_id, name, category, price, stock, is_available FROM products ORDER BY stock ASC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getString("category"),
                    rs.getBigDecimal("price"),
                    rs.getInt("stock"),
                    rs.getBoolean("is_available") ? "Ya" : "Tidak"
                };
                stockTableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat status stok: " + ex.getMessage());
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    // LOGIKA TRANSAKSI GANDA
    private void processRestock() {
        if (productCombo.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(this, "Pilih produk terlebih dahulu.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
            if (quantity <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah Masuk harus angka positif.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        ProductItem selectedItem = productList.get(productCombo.getSelectedIndex());
        int productId = selectedItem.getId();
        String reason = reasonField.getText().trim();
        
        if (reason.isEmpty()) {
             reason = "Restock manual";
        }
        
        Connection conn = null;
        
        try {
            conn = DatabaseConnector.getConnection();
            conn.setAutoCommit(false); // START TRANSACTION
            
            // 1. UPDATE products
            String updateSql = "UPDATE products SET stock = stock + ? WHERE product_id = ?";
            try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                updateStmt.setInt(1, quantity);
                updateStmt.setInt(2, productId);
                updateStmt.executeUpdate();
            }

            // 2. INSERT stock_movements (Audit)
            String insertSql = "INSERT INTO stock_movements (product_id, user_id, type, quantity_change, reason) VALUES (?, ?, 'IN', ?, ?)";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setInt(1, productId);
                insertStmt.setInt(2, adminUserId); 
                insertStmt.setInt(3, quantity);
                insertStmt.setString(4, reason);
                insertStmt.executeUpdate();
            }
            
            conn.commit(); // COMMIT
            JOptionPane.showMessageDialog(this, "Restock " + selectedItem.name + " sebanyak " + quantity + " berhasil diproses!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            
            quantityField.setText("");
            reasonField.setText("");
            loadStockData(); 

        } catch (SQLException ex) {
            try {
                if (conn != null) {
                    conn.rollback(); // ROLLBACK
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Restock Gagal (Transaksi dibatalkan): " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                 e.printStackTrace();
            }
            DatabaseConnector.closeConnection(conn);
        }
    }
}