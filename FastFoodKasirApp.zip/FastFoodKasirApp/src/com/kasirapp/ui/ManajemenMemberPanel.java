package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ManajemenMemberPanel extends JPanel {

    private JTextField txtFullName, txtPhoneNumber;
    private JButton btnAdd, btnUpdate, btnDelete;
    private JTable table;
    private DefaultTableModel tableModel;
    private int selectedMemberId = -1;

    public ManajemenMemberPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Setup Form
        JPanel inputPanel = createInputPanel();
        add(inputPanel, BorderLayout.NORTH);

        // Setup Table
        JScrollPane tableScrollPane = createTablePanel();
        add(tableScrollPane, BorderLayout.CENTER);

        loadMemberData();
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Manajemen Data Member"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label dan Field Nama Lengkap
        gbc.gridx = 0; gbc.gridy = 0; panel.add(new JLabel("Nama Lengkap:"), gbc);
        gbc.gridx = 1; txtFullName = new JTextField(20); panel.add(txtFullName, gbc);

        // Label dan Field Nomor Telepon
        gbc.gridx = 0; gbc.gridy = 1; panel.add(new JLabel("Nomor Telepon:"), gbc);
        gbc.gridx = 1; txtPhoneNumber = new JTextField(20); panel.add(txtPhoneNumber, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btnAdd = new JButton("Tambah");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Hapus");
        
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        
        gbc.gridx = 2; gbc.gridy = 0; gbc.gridheight = 2; panel.add(buttonPanel, gbc);
        
        setupListeners();
        
        return panel;
    }

    private JScrollPane createTablePanel() {
        String[] columnNames = {"ID", "Nama Lengkap", "Nomor Telepon", "Tanggal Gabung"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                displaySelectedMember();
            }
        });
        return new JScrollPane(table);
    }
    
    private void setupListeners() {
        btnAdd.addActionListener(e -> addMember());
        btnUpdate.addActionListener(e -> updateMember());
        btnDelete.addActionListener(e -> deleteMember());
    }
    
    // --- CRUD OPERATIONS ---
    
    private void loadMemberData() {
        tableModel.setRowCount(0);
        selectedMemberId = -1;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            stmt = conn.createStatement();
            // Asumsi kolom join_date ada dan menggunakan NOW() saat INSERT
            rs = stmt.executeQuery("SELECT member_id, full_name, phone_number, join_date FROM members ORDER BY full_name");

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("member_id"),
                    rs.getString("full_name"),
                    rs.getString("phone_number"),
                    rs.getTimestamp("join_date")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data member: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
    
    private void displaySelectedMember() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        selectedMemberId = (int) tableModel.getValueAt(row, 0);
        txtFullName.setText(tableModel.getValueAt(row, 1).toString());
        txtPhoneNumber.setText(tableModel.getValueAt(row, 2).toString());
    }
    
    private void addMember() {
        String fullName = txtFullName.getText().trim();
        String phoneNumber = txtPhoneNumber.getText().trim();
        
        if (fullName.isEmpty() || phoneNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama dan Nomor Telepon wajib diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Memastikan nomor telepon hanya angka (opsional)
        if (!phoneNumber.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Nomor telepon harus berupa angka.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnector.getConnection();
             // Menggunakan NOW() atau CURRENT_TIMESTAMP untuk join_date di PostgreSQL
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO members (full_name, phone_number, join_date) VALUES (?, ?, NOW())")) {
            
            pstmt.setString(1, fullName);
            pstmt.setString(2, phoneNumber);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Member berhasil ditambahkan.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadMemberData();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menambah member: " + ex.getMessage() + "\nMungkin nomor telepon sudah terdaftar.", "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateMember() {
        if (selectedMemberId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih member yang akan diupdate.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String fullName = txtFullName.getText().trim();
        String phoneNumber = txtPhoneNumber.getText().trim();

        if (fullName.isEmpty() || phoneNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama dan Nomor Telepon wajib diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (!phoneNumber.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Nomor telepon harus berupa angka.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE members SET full_name = ?, phone_number = ? WHERE member_id = ?")) {
            
            pstmt.setString(1, fullName);
            pstmt.setString(2, phoneNumber);
            pstmt.setInt(3, selectedMemberId);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Member berhasil diupdate.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
            loadMemberData();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal mengupdate member: " + ex.getMessage() + "\nMungkin nomor telepon sudah terdaftar.", "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteMember() {
        if (selectedMemberId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih member yang akan dihapus.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus member " + txtFullName.getText() + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnector.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM members WHERE member_id = ?")) {
                
                pstmt.setInt(1, selectedMemberId);
                pstmt.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Member berhasil dihapus.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
                loadMemberData();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus member: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void clearFields() {
        txtFullName.setText("");
        txtPhoneNumber.setText("");
        selectedMemberId = -1;
        table.clearSelection();
    }
}