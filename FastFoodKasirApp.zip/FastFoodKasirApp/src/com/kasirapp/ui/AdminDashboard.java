package com.kasirapp.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class AdminDashboard extends JFrame {

    private int userId; 
    private String fullName;
    private JTabbedPane contentPane;
    
    private static final String CMD_MENU = "Manajemen Menu";
    private static final String CMD_RESTOCK = "Restock & Stok";
    private static final String CMD_LAP_JUAL = "Laporan Penjualan";
    private static final String CMD_LAP_STOK = "Laporan Restock";
    private static final String CMD_MEJA = "Manajemen Meja";
    private static final String CMD_MEMBER = "Manajemen Member";

    public AdminDashboard(int userId, String fullName) {
        this.userId = userId;
        this.fullName = fullName;
        
        setTitle("ADMIN Dashboard - Logged in as: " + fullName);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setupMenuBar();

        contentPane = new JTabbedPane();
        
        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        mainSplit.setDividerLocation(220); 
        mainSplit.setDividerSize(5);
        
        mainSplit.setLeftComponent(createNavigationPanel());
        mainSplit.setRightComponent(contentPane);
        
        showInitialDashboard();
        
        add(mainSplit, BorderLayout.CENTER);
    }
    
    // SETUP NAVIGATION (KIRI)
    private JScrollPane createNavigationPanel() {
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        navPanel.setBackground(new Color(245, 245, 245));

        JLabel title = new JLabel("MENU ADMINISTRATOR");
        title.setFont(new Font("Arial", Font.BOLD, 14));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        navPanel.add(title);
        navPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton btnMenu = createNavButton("Menu Management", CMD_MENU);
        JButton btnRestock = createNavButton("Restock & Stok", CMD_RESTOCK);
        JButton btnLaporanJual = createNavButton("Laporan Penjualan", CMD_LAP_JUAL);
        JButton btnLaporanStok = createNavButton("Laporan Restock", CMD_LAP_STOK);
        JButton btnMeja = createNavButton("Manajemen Meja", CMD_MEJA);
        JButton btnMember = createNavButton("Manajemen Member", CMD_MEMBER);
        
        for(JButton btn : new JButton[]{btnMenu, btnRestock, btnLaporanJual, btnLaporanStok, btnMeja, btnMember}) {
            navPanel.add(btn);
            navPanel.add(Box.createRigidArea(new Dimension(0, 8))); 
        }
        
        return new JScrollPane(navPanel);
    }
    
    private JButton createNavButton(String text, String command) {
        JButton btn = new JButton(text);
        btn.setActionCommand(command);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.addActionListener(new TabSwitcherListener());
        return btn;
    }
    
    private void showInitialDashboard() {
        JPanel welcomePanel = new JPanel(new GridBagLayout());
        welcomePanel.setBackground(Color.WHITE);
        JLabel welcomeLabel = new JLabel("<html><h1 style='color:#333;'>Selamat Datang, " + fullName + "</h1><p style='color:#666;'>Pilih menu di sisi kiri untuk memulai manajemen data.</p></html>", SwingConstants.CENTER);
        welcomePanel.add(welcomeLabel);
        
        contentPane.addTab("Dashboard", welcomePanel);
    }

    // LOGIKA TAB SWITCHER
    private class TabSwitcherListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            
            if (contentPane.indexOfTab(cmd) != -1) {
                contentPane.setSelectedIndex(contentPane.indexOfTab(cmd));
                return;
            }
            
            JPanel newPanel;
            
            if (cmd.equals(CMD_MENU)) {
                newPanel = new ManajemenMenuPanel();
            } else if (cmd.equals(CMD_RESTOCK)) {
                newPanel = new RestockPanel(userId); 
            } else if (cmd.equals(CMD_LAP_JUAL)) {
                // Laporan Penjualan
                newPanel = new LaporanPenjualanPanel();
            } else if (cmd.equals(CMD_LAP_STOK)) {
                // Laporan Restock
                newPanel = new LaporanRestockPanel();
            } else if (cmd.equals(CMD_MEJA)) {
                newPanel = new ManajemenMejaPanel();
            } else if (cmd.equals(CMD_MEMBER)) {
                newPanel = new ManajemenMemberPanel();
            } else {
                return;
            }
            
            contentPane.addTab(cmd, newPanel);
            contentPane.setSelectedIndex(contentPane.getTabCount() - 1);
        }
    }
    
    private JPanel createDummyPanel(String text) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.add(new JLabel("<html><p style='font-size:14pt; color:gray; text-align:center;'>"+text+"</p></html>"));
        return panel;
    }
    
    // MENU BAR (LOGOUT)
    private void setupMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuAplikasi = new JMenu("Aplikasi");
        
        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.CTRL_MASK));
        
        logoutItem.addActionListener(e -> {
            int dialogResult = JOptionPane.showConfirmDialog(this, "Anda yakin ingin Logout?", "Konfirmasi Logout", JOptionPane.YES_NO_OPTION);
            if (dialogResult == JOptionPane.YES_OPTION) {
                new LoginForm().setVisible(true);
                this.dispose();
            }
        });
        
        menuAplikasi.add(logoutItem);
        menuBar.add(menuAplikasi);
        setJMenuBar(menuBar);
    }
}