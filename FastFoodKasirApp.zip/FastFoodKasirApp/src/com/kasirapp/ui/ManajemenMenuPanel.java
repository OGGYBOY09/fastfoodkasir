package com.kasirapp.ui;

import com.kasirapp.database.DatabaseConnector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class ManajemenMenuPanel extends JPanel {

    private JTextField nameField, priceField, stockField;
    private JComboBox<String> categoryCombo;
    private JCheckBox availableCheck;
    private JButton addButton, updateButton, deleteButton, clearButton;
    private JTable productTable;
    private DefaultTableModel tableModel;
    private int selectedProductId = -1; // Untuk menyimpan ID produk yang dipilih dari tabel

    public ManajemenMenuPanel() {
        setLayout(new BorderLayout(10, 10)); // Layout utama panel
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- 1. Panel Form Input (Kiri) ---
        JPanel inputPanel = createInputPanel();
        
        // --- 2. Panel Tabel (Kanan/Tengah) ---
        JPanel tableContainer = createTablePanel();

        // Menggabungkan Panel Input dan Tabel menggunakan JSplitPane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, inputPanel, tableContainer);
        splitPane.setDividerLocation(350); // Lebar panel input 350px

        add(splitPane, BorderLayout.CENTER);
        
        // Muat data awal
        loadProductData();
    }

    // ===============================================
    // BAGIAN 1: PEMBUATAN KOMPONEN INPUT
    // ===============================================
    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Manajemen Detail Menu"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        String[] categories = {"Makanan Utama", "Minuman", "Snack", "Dessert"};

        // Komponen
        nameField = new JTextField(20);
        priceField = new JTextField(20);
        stockField = new JTextField(20);
        categoryCombo = new JComboBox<>(categories);
        availableCheck = new JCheckBox("Tersedia untuk Dijual", true);

        // Fungsi Helper untuk menambahkan label dan field
        int row = 0;
        row = addField(panel, gbc, row, new JLabel("Nama Menu:"), nameField);
        row = addField(panel, gbc, row, new JLabel("Kategori:"), categoryCombo);
        row = addField(panel, gbc, row, new JLabel("Harga (Rp):"), priceField);
        row = addField(panel, gbc, row, new JLabel("Stok Awal:"), stockField);
        
        // Checkbox Tersedia
        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.gridwidth = 2;
        panel.add(availableCheck, gbc);

        // Panel Tombol
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 0));
        addButton = new JButton("Tambah");
        updateButton = new JButton("Ubah");
        deleteButton = new JButton("Hapus");
        clearButton = new JButton("Clear");
        
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        
        gbc.gridy = row++;
        gbc.insets = new Insets(20, 0, 0, 0); // Tambah spasi di atas tombol
        panel.add(buttonPanel, gbc);

        // --- Aksi Tombol ---
        addButton.addActionListener(e -> createProduct());
        updateButton.addActionListener(e -> updateProduct());
        deleteButton.addActionListener(e -> deleteProduct());
        clearButton.addActionListener(e -> clearForm());
        
        return panel;
    }
    
    // Helper method untuk GridBagLayout
    private int addField(JPanel panel, GridBagConstraints gbc, int row, JComponent label, JComponent field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panel.add(field, gbc);
        return row + 1;
    }

    // ===============================================
    // BAGIAN 2: PEMBUATAN TABEL
    // ===============================================
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Daftar Menu Saat Ini"));

        // Definisi Kolom Tabel
        String[] columnNames = {"ID", "Nama Menu", "Kategori", "Harga", "Stok", "Tersedia"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Mencegah editing langsung di tabel
            }
        };
        productTable = new JTable(tableModel);
        
        // Mouse Listener untuk memilih data
        productTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                fillFormFromTable();
            }
        });
        
        panel.add(new JScrollPane(productTable), BorderLayout.CENTER);
        return panel;
    }

    // ===============================================
    // BAGIAN 3: LOGIKA DATABASE (CRUD)
    // ===============================================

    // READ: Memuat data dari database ke JTable
    private void loadProductData() {
        tableModel.setRowCount(0); // Bersihkan tabel
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnector.getConnection();
            String sql = "SELECT product_id, name, category, price, stock, is_available FROM products ORDER BY product_id";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getString("category"),
                    rs.getBigDecimal("price"),
                    rs.getInt("stock"),
                    rs.getBoolean("is_available") ? "Ya" : "Tidak"
                };
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data menu: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    // CREATE: Menambahkan menu baru
    private void createProduct() {
        if (!validateInput()) return;

        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DatabaseConnector.getConnection();
            String sql = "INSERT INTO products (name, category, price, stock, is_available) VALUES (?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, nameField.getText());
            pstmt.setString(2, categoryCombo.getSelectedItem().toString());
            pstmt.setBigDecimal(3, new java.math.BigDecimal(priceField.getText()));
            pstmt.setInt(4, Integer.parseInt(stockField.getText()));
            pstmt.setBoolean(5, availableCheck.isSelected());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Menu berhasil ditambahkan.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadProductData(); // Muat ulang data
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal menambahkan menu: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Harga dan Stok harus berupa angka yang valid.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }

    // UPDATE: Mengubah detail menu yang ada
    private void updateProduct() {
        if (selectedProductId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih menu dari tabel untuk diubah.", "Perhatian", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!validateInput()) return;

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnector.getConnection();
            String sql = "UPDATE products SET name=?, category=?, price=?, stock=?, is_available=? WHERE product_id=?";
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, nameField.getText());
            pstmt.setString(2, categoryCombo.getSelectedItem().toString());
            pstmt.setBigDecimal(3, new java.math.BigDecimal(priceField.getText()));
            pstmt.setInt(4, Integer.parseInt(stockField.getText()));
            pstmt.setBoolean(5, availableCheck.isSelected());
            pstmt.setInt(6, selectedProductId);
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Menu berhasil diubah.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadProductData();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal mengubah menu: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Harga dan Stok harus berupa angka yang valid.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            DatabaseConnector.closeConnection(conn);
        }
    }
    
    // DELETE: Menghapus menu
    private void deleteProduct() {
        if (selectedProductId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih menu dari tabel untuk dihapus.", "Perhatian", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int dialogResult = JOptionPane.showConfirmDialog(this, 
                "Anda yakin ingin menghapus menu ini?\nStok terkait akan ikut terhapus dari riwayat.", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        
        if (dialogResult == JOptionPane.YES_OPTION) {
            Connection conn = null;
            PreparedStatement pstmt = null;

            try {
                conn = DatabaseConnector.getConnection();
                // Hapus data produk
                String sql = "DELETE FROM products WHERE product_id=?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, selectedProductId);
                
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Menu berhasil dihapus.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    clearForm();
                    loadProductData();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus menu: " + ex.getMessage() + "\nPastikan menu ini tidak digunakan dalam transaksi.", "DB Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } finally {
                DatabaseConnector.closeConnection(conn);
            }
        }
    }

    // ===============================================
    // BAGIAN 4: VALIDASI DAN HELPER FORM
    // ===============================================

    // Mengisi form input saat baris tabel diklik
    private void fillFormFromTable() {
        int i = productTable.getSelectedRow();
        if (i >= 0) {
            try {
                // Ambil product_id (Kolom 0)
                selectedProductId = (int) tableModel.getValueAt(i, 0); 
                nameField.setText(tableModel.getValueAt(i, 1).toString());
                categoryCombo.setSelectedItem(tableModel.getValueAt(i, 2).toString());
                priceField.setText(tableModel.getValueAt(i, 3).toString());
                stockField.setText(tableModel.getValueAt(i, 4).toString());
                availableCheck.setSelected(tableModel.getValueAt(i, 5).toString().equals("Ya"));

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // Membersihkan form
    private void clearForm() {
        nameField.setText("");
        priceField.setText("");
        stockField.setText("");
        categoryCombo.setSelectedIndex(0);
        availableCheck.setSelected(true);
        selectedProductId = -1;
        productTable.clearSelection();
    }
    
    // Validasi input
    private boolean validateInput() {
        if (nameField.getText().trim().isEmpty() || priceField.getText().trim().isEmpty() || stockField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field harus diisi.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        try {
            // Cek Harga dan Stok harus angka
            new java.math.BigDecimal(priceField.getText());
            Integer.parseInt(stockField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Harga dan Stok harus berupa angka yang valid.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
}