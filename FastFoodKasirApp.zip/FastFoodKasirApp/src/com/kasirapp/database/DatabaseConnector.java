package com.kasirapp.database; // Ganti dengan package Anda

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DatabaseConnector {

    // --- KONFIGURASI POSTGRESQL ANDA ---
    private static final String URL = "jdbc:postgresql://localhost:5432/fastfood_kasir"; 
    private static final String USER = "postgres"; // Biasanya user default
    private static final String PASSWORD = "12345"; // GANTI DENGAN PASSWORD POSTGRES ANDA
    // ------------------------------------
    
    // Objek koneksi yang akan digunakan di seluruh aplikasi
    public static Connection getConnection() {
        Connection conn = null;
        try {
            // 1. Memuat Driver JDBC PostgreSQL (hanya perlu di Java versi lama, tapi baik untuk dimasukkan)
            // Class.forName("org.postgresql.Driver"); 
            
            // 2. Membuat Koneksi
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            // System.out.println("Koneksi ke database berhasil!"); // Opsional untuk debugging
            return conn;
            
        } catch (SQLException e) {
            // Tampilkan error jika koneksi gagal
            JOptionPane.showMessageDialog(null, 
                "Koneksi Database Gagal!\nPastikan PostgreSQL dan pgAdmin4 berjalan.\nError: " + e.getMessage(), 
                "Koneksi Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            return null; // Mengembalikan null jika koneksi gagal
        }
    }
    
    // Method untuk menutup koneksi
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Gagal menutup koneksi: " + e.getMessage());
            }
        }
    }
    
    // Contoh untuk tes koneksi (bisa dijalankan di main method)
    public static void main(String[] args) {
        Connection testConn = getConnection();
        if (testConn != null) {
            System.out.println("Koneksi Berhasil!");
            closeConnection(testConn);
        } else {
            System.out.println("Koneksi Gagal.");
        }
    }
}